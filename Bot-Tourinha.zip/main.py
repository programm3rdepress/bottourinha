import discord
from discord.ext import commands

intents = discord.Intents.default()
intents.members = True
intents = discord.Intents(
messages=True, guilds=True, reactions=True, members=True)

client = commands.Bot(command_prefix = "t!", case_insensitive = True, intents = intents)

#EVENTOS

@client.event
async def on_ready():
  print('Fala tropinha! Mãe ta on viu?')

@client.event
async def on_member_join(member):
  canal = client.get_channel(845164017428332545)
  regras = client.get_channel(845089364732411904)
  whitelist = client.get_channel(845096841930473482)
  bemvindo=discord.Embed(title=f'Bem-vindo a tropa, {member.mention}!', color=0xffa200, description=f'Leia as regras em {regras.mention} e se inscreva para a whitelist em {whitelist.mention}!')
  bemvindo.add_field(name='ID', value=member.id)
  bemvindo.add_field(name='Nome', value=member.name)
  bemvindo.set_author(name='Prefeitura', icon_url='https://i.imgur.com/fOlgOU0.jpg')
  bemvindo.set_thumbnail (url='https://i.imgur.com/fOlgOU0.jpg')
  bemvindo.set_image (url='https://media.discordapp.net/attachments/844036659023839282/845491651392962600/banner_fivem.png?width=1440&height=95')
  await canal.send(embed=bemvindo)

@client.event
async def on_ready():
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name='Roleplay na Fox City'))

@client.event
async def on_member_join(ctx):
    autorole = discord.utils.get(ctx.guild.roles, name = '『❌』Sem Passaporte')
    await ctx.add_roles(autorole)

#COMANDOS

@client.command()
async def whitelist(ctx):
  ip = client.get_channel(845095554622554122)
  await ctx.message.add_reaction('✅')
  await ctx.send(f'Eai, {ctx.author}, pra fazer a nossa Whitelist cê precisa entrar na cidade pra pegar sua ID. É só cê entrar ali em {ip.mention} e seguir os passos pra entrar na cidade, quando entra na cidade pela primeira vez aparece naquela telinha seu ID tlgd? Feito isso é só você aguardar alguém da prefeitura te puxar pra call pra fazer sua entrevista! Boa sorte pit.')

@client.command()
async def serveron(ctx):
  embed = discord.Embed(
    title = 'FAVELA VENCEU E CIDADE VOLTOU TROPA!!!!' ,
    description = 'Não perde tempo meus pit e ja conecta na melhor city do BR!',
    colour = 15431961
  )

  embed.set_author(name='Prefeitura', icon_url='https://i.imgur.com/fOlgOU0.jpg')

  embed.set_thumbnail (url='https://i.imgur.com/fOlgOU0.jpg')

  embed.set_image(url='https://i.pinimg.com/564x/7a/62/4b/7a624bba75d853349eb41a791395c6f4.jpg')

  embed.set_footer(text=f'Mete um F8 nesse FiveM e digita connect 191.101.131.55:30120')

  await ctx.send(embed = embed)

@client.command()
async def serverof(ctx):
  embed = discord.Embed(
    title = 'Opa familia, sofremos um terremoto..' ,
    description = 'Mas fica suave tropa que já ja nos ta de volta!',
    colour = 15431961
  )

  embed.set_author(name='Prefeitura', icon_url='')

  embed.set_thumbnail (url='https://i.imgur.com/fOlgOU0.jpg')

  embed.set_image(url='https://i.pinimg.com/564x/9d/ae/cb/9daecb2bc2a4f3b9de8b5858f7bb4d6e.jpg')

  await ctx.send(embed = embed)

@client.command()
async def limpar(ctx, amount=5):
  if ctx.author.guild_permissions.administrator:
    await ctx.channel.purge(limit=amount)
  else:
    await ctx.sedn('Calma lá pit, tu é quem?')

@client.command()
async def kick(ctx, member : discord.Member, *, reason=None):
  if ctx.author.guild_permissions.administrator:
    await member.kick(reson=reason)
  else:
    await ctx.sedn('Calma lá pit, tu é quem?')

@client.command()
async def ban(ctx, member : discord.Member, *, reason=None):
  if ctx.author.guild_permissions.administrator:
    await member.ban(reson=reason)
  else:
    await ctx.sedn('Calma lá pit, tu é quem?')


client.run('ODQ1MTYxODUwNTc2MzA2MTk2.YKc8Tw.vRC30-DQIZ8cbPLKLCQ_NRhW_nc')
